const files = {
    template: `
        <div id="files-template">
            <template>
                <file-players>
            </template>
        </div>
    `
}