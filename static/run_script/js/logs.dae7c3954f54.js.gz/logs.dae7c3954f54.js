const logs = {
    template: `
        <div id="logs-template">
            <template>
                <scrapper-logs />
            </template>
        </div>
    `
}