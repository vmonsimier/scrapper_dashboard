const files = {
    template: `
        <div id="files-template">
            <template>
                <file_players>
            </template>
        </div>
    `
}