const scrappers = {
  data() {
    return {
      
    }
  },

  template: `
  <div id="scrapper-table-template">
    <template>
      <scrappers-table />
    </template>
  </div>
  `
}
