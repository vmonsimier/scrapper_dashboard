const scrappers = {
  data() {

  },

  template: `
  <div id="scrapper-table-template">
    <template>
    </template>
  </div>
  `
}
